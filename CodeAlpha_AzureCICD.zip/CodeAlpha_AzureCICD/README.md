# CodeAlpha_AzureCICD

**Stage DevOps — Tâche 1 : CI/CD Pipeline using Azure**

Pipeline CI/CD complet avec Azure Pipelines : build de l'image Docker, publication sur
Azure Container Registry (ACR), et déploiement automatique sur Azure App Service
(Web App for Containers), avec infrastructure provisionnée en Bicep (IaC).

## 📁 Structure du projet

```
CodeAlpha_AzureCICD/
├── app/                     # Application Node.js conteneurisée (réutilisée et testée)
│   ├── server.js
│   ├── package.json
│   └── test.js
├── infra/
│   └── main.bicep           # IaC : ACR + App Service Plan + Web App
├── Dockerfile
├── azure-pipelines.yml      # Pipeline Build → Push → Deploy
└── README.md
```

## 🏗️ Architecture du pipeline

```
 Push sur "main"
        │
        ▼
 ┌─────────────┐    ┌──────────────────┐    ┌─────────────────────┐
 │   BUILD     │ →  │      PUSH        │ →  │       DEPLOY         │
 │ npm test    │    │ Image → ACR      │    │ ACR → App Service    │
 │ docker build│    │ (tag = BuildId)  │    │ + smoke test /health │
 └─────────────┘    └──────────────────┘    └─────────────────────┘
```

## 🚀 Mise en place (à faire une seule fois, avec ton propre abonnement Azure)

### 1. Provisionner l'infrastructure avec Bicep

```bash
az login
az group create --name rg-codealpha-devops --location francecentral

az deployment group create \
  --resource-group rg-codealpha-devops \
  --template-file infra/main.bicep \
  --parameters appName=codealpha-webapp acrName=codealphaacr$RANDOM
```

Cette commande crée :
- un **Azure Container Registry** (stockage des images Docker)
- un **App Service Plan Linux** (B1)
- une **Web App for Containers** configurée pour pointer vers l'image ACR, avec health check sur `/health`

### 2. Créer les Service Connections dans Azure DevOps

Dans **Project Settings > Service connections** :

| Type                     | Nom à utiliser                  | Pointe vers                         |
|--------------------------|----------------------------------|--------------------------------------|
| Docker Registry          | `codealpha-acr-connection`       | Le registre ACR créé ci-dessus       |
| Azure Resource Manager   | `codealpha-azure-connection`     | Ton abonnement Azure                 |

> Mets à jour les noms dans la section `variables:` de `azure-pipelines.yml` si tu les nommes différemment.

### 3. Créer le pipeline

Dans Azure DevOps : **Pipelines > New Pipeline > GitHub** → sélectionne ce repo →
Azure Pipelines détecte automatiquement `azure-pipelines.yml`.

## 📊 Monitorer le pipeline

- **Azure DevOps > Pipelines** : historique des exécutions, logs détaillés par étape/tâche.
- **Azure Portal > App Service > Log stream** : logs applicatifs en temps réel.
- **Azure Portal > App Service > Diagnose and solve problems** : diagnostic automatique
  (santé du conteneur, erreurs HTTP, performance).
- Le health check `/health` est interrogé par App Service ET par le pipeline lui-même
  (étape "Vérifier le déploiement") pour confirmer que le déploiement a réussi.

## 🔒 Bonnes pratiques appliquées

- **IaC (Bicep)** : infrastructure reproductible et versionnée, pas de clic-clic manuel dans le portail.
- **Tag d'image = Build ID** : chaque déploiement est traçable à un build précis (pas seulement `latest`).
- **HTTPS only** activé sur l'App Service.
- **Health check** intégré à chaque étape (Dockerfile, App Service, pipeline).
- **Séparation des stages** (Build / Push / Deploy) : un échec de test bloque le déploiement.

## 📤 Pour la soumission CodeAlpha

```bash
git init
git add .
git commit -m "Initial commit - Azure CI/CD Pipeline"
git branch -M main
git remote add origin https://github.com/<ton-username>/CodeAlpha_AzureCICD.git
git push -u origin main
```
